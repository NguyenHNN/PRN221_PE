﻿USE master
GO

CREATE DATABASE CoppaItalia2024DB
GO

USE CoppaItalia2024DB
GO

CREATE TABLE CoppaItaliaAccount (
  AccID int primary key,
  AccPassword nvarchar(90) not null,
  EmailAddress nvarchar(90) unique, 
  AccDescription nvarchar(140) not null,
  AccRole int
)
GO

INSERT INTO CoppaItaliaAccount VALUES(551 ,N'@4','admin@CoppaItalia.com', N'System Admin', 1);
INSERT INTO CoppaItaliaAccount VALUES(552 ,N'@4','staff@CoppaItalia.com', N'Staff', 2);
INSERT INTO CoppaItaliaAccount VALUES(553 ,N'@4','manager@CoppaItalia.com', N'Manager', 3);
INSERT INTO CoppaItaliaAccount VALUES(554 ,N'@4','member1@CoppaItalia.com', N'Member', 4);
GO

CREATE TABLE CoppaItaliaClub (
  CoppaItaliaClubID nvarchar(20) primary key,
  ClubName nvarchar(100) not null,
  ShortDescription nvarchar(250),
  FoundedDate Datetime,
  Ground nvarchar(120) not null, 
  Website nvarchar(250) not null, 
  CurrentPresident nvarchar(100) not null
)
GO

INSERT INTO CoppaItaliaClub VALUES(N'CL007780', N'Juventus FC', N'One of the most successful and iconic football clubs in Italy, known for its dominance in Serie A and international competitions.', CAST(N'November 1, 1897' AS DateTime),  N'Allianz Stadium, Turin, Italy', N'[Juventus Official Website](https://www.juventus.com)', N'Andrea Agnelli')
GO
INSERT INTO CoppaItaliaClub VALUES(N'CL007781', N'AC Milan', N'A historic club with a rich tradition, known for its passionate fanbase and numerous domestic and European trophies.',  CAST(N'December 16, 1899' AS DateTime),  N'San Siro Stadium, Milan, Italy', N'[AC Milan Official Website](https://www.acmilan.com)', N'Paolo Scaroni')
GO
INSERT INTO CoppaItaliaClub VALUES(N'CL007782', N'SS Lazio', N'Based in Rome, Lazio is known for its fierce rivalry with AS Roma and has a strong history of competing at the top level of Italian football.',  CAST(N'January 9, 1900' AS DateTime),  N'Stadio Olimpico, Rome, Italy', N'[SS Lazio Official Website](https://www.sslazio.it)', N'Claudio Lotito')
GO
INSERT INTO CoppaItaliaClub VALUES(N'CL007783', N'Inter Milan', N'One of the giants of Italian football, Inter Milan has a storied history, including multiple Serie A titles and European successes.',  CAST(N'March 9, 1908' AS DateTime),  N'San Siro Stadium, Milan, Italy', N'[Inter Milan Official Website](https://www.inter.it)', N'Steven Zhang')
GO
INSERT INTO CoppaItaliaClub VALUES(N'CL007784', N'AS Roma', N'A club deeply rooted in the city of Rome, AS Roma has a passionate fanbase and a history of producing top talent in Italian football.',  CAST(N'July 22, 1927' AS DateTime),  N'Stadio Olimpico, Rome, Italy', N'[AS Roma Official Website](https://www.asroma.com)', N'Dan Friedkin')
GO





CREATE TABLE CoppaItaliaPlayer (
  CoppaItaliaPlayerID nvarchar(30) PRIMARY KEY,
  FullName nvarchar(100) not null,
  Position nvarchar(100) not null, 
  Birthday Datetime,
  InternationalCareer nvarchar(400) not null, 
  StyleOfPlay nvarchar(400) not null, 
  CoppaItaliaClubID nvarchar(20) FOREIGN KEY references CoppaItaliaClub(CoppaItaliaClubID) on delete cascade on update cascade,
)
GO


INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133441', N'Cristiano Ronaldo', N'Forward', CAST(N'February 5, 1985' AS DateTime), N'Cristiano Ronaldo has represented Portugal since 2003 and is their all-time top scorer and most capped player. He has won the UEFA European Championship in 2016 and the UEFA Nations League in 2019.', N'Known for his athleticism, dribbling skills, and goal-scoring ability, Ronaldo is a versatile forward who can play on either wing or as a center-forward. He is renowned for his aerial prowess, powerful shots, and ability to perform under pressure.', N'CL007780')
GO
INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133442', N'Giorgio Chiellini', N'Defender (Center-back)', CAST(N'August 14, 1984' AS DateTime), N'Giorgio Chiellini has been a mainstay in the Italian national team since 2004, playing in multiple UEFA European Championships and FIFA World Cups. He was part of the Italian squad that won UEFA Euro 2020.', N'Chiellini is known for his leadership qualities, excellent positioning, and tough tackling. He excels in aerial duels and is adept at reading the game, making him a stalwart in defense.', N'CL007780')
GO
INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133443', N'Paulo Dybala', N'Forward (Attacking Midfielder/Second Striker)', CAST(N'November 15, 1993' AS DateTime), N'Paulo Dybala has represented Argentina at various youth levels and made his senior debut in 2015. He has been part of Argentina s squads in Copa America tournaments.', N'Dybala is known for his dribbling skills, creativity, and ability to score goals from distance. He operates behind the striker(s) or on the wings, using his vision and technical ability to create chances for himself and his teammates.', N'CL007780')
GO
INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133444', N'Federico Chiesa', N'Forward (Winger)', CAST(N'October 25, 1997' AS DateTime), N'Federico Chiesa made his debut for the Italian national team in 2018 and has since become a key player, contributing to Italy s success in UEFA Euro 2020 where they emerged as champions.', N'Chiesa is known for his pace, dribbling ability, and direct style of play. He operates primarily as a winger, using his agility and crossing ability to create goal-scoring opportunities. He is also capable of cutting inside and taking shots from distance.', N'CL007780')
GO

INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133445', N'Zlatan Ibrahimović', N'Forward', CAST(N'October 3, 1981' AS DateTime), N'Zlatan Ibrahimović has represented Sweden at various international tournaments, including the UEFA European Championship and the FIFA World Cup. He retired from international football in 2016 but returned briefly in 2021.', N'Known for his physical presence, technical ability, and powerful shots, Ibrahimović is a complete forward who can score with both feet and his head. He is also adept at holding up play and linking up with teammates.', N'CL007781')
GO
INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133446', N'Gianluigi Donnarumma', N'Goalkeeper', CAST(N'February 25, 1999' AS DateTime), N'Gianluigi Donnarumma made his debut for the Italian national team in 2016 and has since become their first-choice goalkeeper. He played a crucial role in Italy s victory at UEFA Euro 2020, winning the Best Player of the Tournament award.', N'Donnarumma is known for his shot-stopping ability, reflexes, and commanding presence in the penalty area. He is also comfortable with the ball at his feet and has excellent distribution skills.', N'CL007781')
GO
INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133447', N'Franck Kessié', N'Midfielder (Central Midfielder/Defensive Midfielder)', CAST(N'December 19, 1996' AS DateTime), N'Franck Kessié represents the Ivory Coast national team and has been a regular fixture in their midfield since 2014. He has participated in African Cup of Nations tournaments.', N'Kessié is known for his physicality, stamina, and ability to win duels in midfield. He contributes defensively with interceptions and tackles while also possessing good passing range and scoring ability from set-pieces and penalties.', N'CL007781')
GO
INSERT INTO CoppaItaliaPlayer VALUES(N'PL01133448', N'Sandro Tonali', N'Midfielder (Central Midfielder/Defensive Midfielder)', CAST(N'May 8, 2000' AS DateTime), N'Sandro Tonali made his debut for the Italian national team in 2020 and has since been part of their squad for UEFA European Championship and FIFA World Cup qualifiers.', N'Tonali is known for his vision, passing accuracy, and composure on the ball. He excels in controlling the tempo of the game from midfield, distributing the ball efficiently, and contributing defensively with interceptions and tackles.', N'CL007781')
GO


